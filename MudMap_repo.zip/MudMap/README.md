# MudMap

Segmentação mineral determinística a partir de mapas EDS (um mapa por elemento, exportados do AZtec) e o
**MudMap Studio**, software desktop (PyQt6) para inspecionar, editar, segmentar e gerar o relatório
(Shepard, Na-K-Ca, diâmetros, composição) de cada amostra, num pacote `.mudmap`.

```
app/                  MudMap Studio (mudmap_studio/nucleo = sem Qt; ui = interface; testes/)
scripts/              pipeline de segmentação (o app importa common.py e segmentar.py)
config/               classificacao.yaml (sítio ativo, minerais, regras; tamanhos em µm)
.claude/skills/       runbooks do Claude: S_MudMap (pipeline) e S_MudMapStudio (software)
CLAUDE.md             contexto carregado automaticamente pelo Claude Code
--- pacote de dados (MudMap_dados_sitio1.zip) ---
EDS/1/                mapas EDS brutos dos sítios 1.1 e 1.2
estado/               segmentação do sítio ativo (1.2)
sitios/               sítios concluídos (1.1, 1.2) com config e estado
saida/mudmap/         pacotes .mudmap prontos para abrir no app
```

## Criar o repositório no GitHub

Extraia `MudMap_repo.zip` e, dentro da pasta `MudMap/`:

```bash
git init -b main
git add .
git commit -m "MudMap: pipeline + MudMap Studio v0.5.0"
gh repo create MudMap --private --source . --push
```

(Sem o `gh`: crie o repositório vazio no site e use `git remote add origin <url>` + `git push -u origin main`.)

## Dados

Extraia `MudMap_dados_sitio1.zip` **no mesmo lugar** (as pastas se mesclam dentro de `MudMap/`).
Eles ficam fora do git por padrão (dados de pesquisa, ~170 MB). Se o repositório for **privado** e você
quiser versioná-los (por exemplo, para o Claude na nuvem rodar os testes), apague o bloco "DADOS do
sítio 1" do `.gitignore` antes do `git add` — nenhum arquivo passa de 10 MB.
Os mapas dos sítios 2–4 (1,1 GB) não estão incluídos.

## Instalar e testar (Python 3.12)

```bash
python -m venv .venv
pip install -r requirements.txt
python app/testes/validar_nucleo.py
QT_QPA_PLATFORM=offscreen python app/testes/testar_interface.py
python app/run_studio.py saida/mudmap/RJS0649RJ_1.1.mudmap
```

O executável Windows é gerado por `app/build_exe.ps1` (PyInstaller; ajuste o caminho do Python na linha 10).

## Com o Claude Code

Abra a pasta no Claude Code: o `CLAUDE.md` é lido sozinho. Use `/S_MudMap` para o pipeline e
`/S_MudMapStudio` para o software — cada runbook termina com o estado atual e o próximo passo.
