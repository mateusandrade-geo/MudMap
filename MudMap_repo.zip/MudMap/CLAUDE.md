# MudMap — contexto para o Claude

Segmentação mineral **determinística** a partir de mapas EDS (AZtec, um mapa por elemento) e o software
desktop **MudMap Studio** (PyQt6 → .exe) que revisa/edita/relata a segmentação. Este repositório é uma
réplica do projeto original (Windows 10, pasta no OneDrive), empacotada em 2026-09-30.

## Runbooks = fonte de verdade (ler antes de agir)

| frente | comando | arquivo |
|---|---|---|
| pipeline (`scripts/`, `config/`, `estado/`, `sitios/`) | `/S_MudMap` | `.claude/skills/S_MudMap/SKILL.md` |
| software (`app/`) | `/S_MudMapStudio` | `.claude/skills/S_MudMapStudio/SKILL.md` |

Cada runbook termina em **Estado / próximo passo**. Ao concluir uma etapa, atualizar essa seção.

**Estado em 2026-09-30:** sítios 1.1 e 1.2 concluídos (1.2 = sítio ativo em `estado/`); sítios 2–4
aguardam o USUÁRIO organizar `EDS/2..4` em subpastas — não começar antes. App v0.5.0 (fases 1–5 feitas),
aguardando o retorno do usuário.

## Preferências do usuário (valem sempre)

- Conversar em português. Perguntar sempre que a opinião dele contar; entregar por fases testadas.
- Nunca editar dados/config do usuário por conta própria (testes só em cópias); nunca descartar trabalho
  commitado sem confirmar; prévia antes/depois de cada etapa do pipeline (REGRAS do `/S_MudMap`).
- Tokens perto do fim: fazer só o que couber, salvar estado, registrar no SKILL.md o ponto exato de
  parada e o próximo passo, e pausar pedindo para retomar.

## Ambiente desta réplica (os runbooks citam a máquina original)

| nos runbooks | aqui |
|---|---|
| `$py = "C:\Users\faria\...\Python312\python.exe"` | o Python 3.12 local; `pip install -r requirements.txt` (versões exatas do original) |
| "Bash falha → usar PowerShell" | vale só na máquina original; em Linux/macOS use bash normalmente |
| `app\build_exe.ps1` → `C:\MudMapStudio\dist\...` + atalho na Área de Trabalho | só Windows; trocar o `$py` fixo na linha 10 pelo Python local |
| OneDrive, `.exe` aberto pelo usuário | não se aplica fora da máquina original |
| links `claude.ai/artifact/...` (inspetores) | pertencem à conta do usuário |

**Dados:** `EDS/1`, `estado/`, `sitios/` e `saida/mudmap/` vêm do pacote `MudMap_dados_sitio1.zip`
(extrair na raiz). Sem eles os testes e o pipeline não rodam. Por padrão ficam fora do git (ver `.gitignore`).

## Testes (rodar da raiz; ambos terminam com `RESULTADO: OK`, ~30 s cada)

```bash
python app/testes/validar_nucleo.py
QT_QPA_PLATFORM=offscreen python app/testes/testar_interface.py
```

Sem tela: `QT_QPA_PLATFORM=offscreen`; se o texto sair vazio, `QT_QPA_FONTDIR=<pasta com .ttf>`
(no Windows `C:/Windows/Fonts`). Em Linux o PyQt6 pode exigir `libgl1 libegl1 libxkbcommon0 libfontconfig1`.
Rodar o app: `python app/run_studio.py [arquivo.mudmap]`.
